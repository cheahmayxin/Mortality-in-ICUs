# ICU Mortality Project: Age, Logistic Regression and Random Forest

This package contains completed, actual-data results for the five assigned indicators: GCS, RespRate, BUN, Creatinine and Urine. Age is the only additional Patient Profile input. All client-facing code, filenames, labels and summaries are in English.

## Read the results

- `ICU_Analysis_Summary.docx`: concise findings, limitations and integration recommendations.
- `Analysis_Summary.md`: an expanded, searchable text companion with all paired metric changes.
- `results/Model_Comparison.xlsx`: six primary models with Age, three no-Age LR references, paired metric changes, input lists and exact settings.
- `results/Feature_Importance.xlsx`: held-out grouped and individual permutation importance, standardized LR coefficients and secondary RF impurity importance.
- `results/Variable_Handoff.xlsx`: an exploratory three-indicator shortlist, Age requirement, proposed feature lists and supporting group statistics.
- `results/Data_Quality_and_Age.xlsx`: field checks, cohort accounting, Age summaries and original-column mapping.
- `results/Analysis_Data.csv`: all assigned indicator summaries and change values; not an automatic model input list.
- `results/Integration_Data.csv`: patient-aligned Age and shortlisted indicators for the final-model owner. Contains both representations and the outcome for handoff; use the explicit model input lists, never every column automatically.
- `figures/`: four analytical PNG images, each at 300 dpi.
- `data/ICU_Preprocessed_Data.csv`: unchanged copy of the supplied original dataset.

## Validation design

The original three feature schemes are retained: Day 1; Day 1 + Day 2; Day 1 + Change. Each includes Age for both LR and RF, producing six primary models. The additional no-Age LR controls measure the effect of adding Age and are not included in the six-model ranking. Change is exactly each patient's Day-2 mean minus Day-1 mean. No model contains x, y and change together.

All models use one common cohort and identical 5-fold x 10-repeat stratified splits, seed 42. Median imputation is fitted inside each training fold. LR uses fold-local StandardScaler; RF does not require scaling. LR uses fixed L2/C=1/lbfgs settings; RF uses 200 trees, min_samples_leaf=3, max_features=sqrt and seed 42. There is no parameter search, resampling or threshold tuning. Death=1 is the positive class; threshold=0.5. Metrics are validation means +/- sample SD, not confidence intervals.

Grouped permutation jointly shuffles all available representations of one indicator, with 3 shuffles on each of 50 held-out folds. Individual importance uses 3 shuffles on the 5 held-out folds of the first repeat. These are model-dependent contributions; correlated indicators may mask each other. Coefficients and RF impurity importance are supplementary, not causal effects.

The shortlist is exploratory: all reported primary model scores use all five assigned indicators plus Age. No performance claim is made for the reduced shortlist. The final-model owner must select/tune inside training folds and validate the final combined model independently.

## Reproduce

The current computer has all dependencies installed. Double-click `run_analysis.cmd`, or run `python run_analysis.py`. A single entry rebuilds the workbooks, figures, handoff CSVs and Word/Markdown summaries without changing the raw data. Existing generated files of the same names will be replaced. No manual data preparation is needed.

The Python versions used are recorded in `requirements.txt`. Word creation also uses Node.js and the globally installed `docx` package; the entry locates its module path automatically. When transferring this project to another computer, the runtime must provide these dependencies. The Word generator is embedded in the main entry; there are no separate report-generation helper files.

Input filenames and column order may change; normalized required-column matching is used. Optional command: `python run_analysis.py --data path/to/input.csv --output path/to/output`. If several different matching datasets exist, explicit selection is required. Patient IDs must be unique. Partially missing values are retained and imputed inside the training fold. Missing outcomes or entirely missing five Day-2 means are excluded consistently for all models and counted explicitly.

Patient-level out-of-fold predictions, fold scores and grouped-importance checks are kept in a verification folder beside the delivery directory, not in the client package. Old deliveries are preserved. This is a component handoff, not the team's final combined model.
