"""Reproduce the ICU Age, Logistic Regression and Random Forest analysis."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.exceptions import ConvergenceWarning
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

INDICATORS = ("GCS", "RespRate", "BUN", "Creatinine", "Urine")
METRICS = ("ROC_AUC", "Recall", "F1", "Accuracy")
TARGET = "In.hospital_death"
SEED, FOLDS, REPEATS, SHUFFLES = 42, 5, 10, 3
SCHEMES = {"D1": "Day 1", "D1_D2": "Day 1 + Day 2", "D1_Change": "Day 1 + Change"}


def normalized(value):
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def match(columns, name):
    candidates = [c for c in columns if normalized(c) == normalized(name)]
    if len(candidates) != 1:
        raise ValueError(f"Expected one match for {name}; found {candidates}.")
    return candidates[0]


def read_file(path):
    if path.suffix.lower() == ".xlsx":
        for frame in pd.read_excel(path, sheet_name=None).values():
            if any(normalized(c) == normalized(TARGET) for c in frame):
                return frame
        raise ValueError("No worksheet contains the outcome column.")
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            frame = pd.read_csv(path, sep=None, engine="python", encoding=encoding)
            frame.columns = [str(c).strip() for c in frame]
            return frame
        except UnicodeError:
            continue
    raise ValueError("Unable to decode the data file.")


def locate_data(root, explicit):
    if explicit:
        return Path(explicit).resolve()
    required = ["Age", TARGET] + [f"Mean_{k}.{t}" for k in INDICATORS for t in ("x", "y")]
    for folder in (root / "data", root.parent):
        matches = []
        for path in sorted(folder.iterdir()):
            if path.suffix.lower() not in (".csv", ".xlsx"):
                continue
            try:
                frame = read_file(path)
                for name in required:
                    match(frame.columns, name)
                matches.append(path)
            except (ValueError, KeyError, pd.errors.ParserError):
                continue
        if matches:
            if len({hashlib.sha256(p.read_bytes()).hexdigest() for p in matches}) != 1:
                raise ValueError("Multiple different valid datasets found; use --data.")
            return matches[0]
    raise FileNotFoundError("No valid ICU file was found in data/ or the parent directory.")


def prepare(raw):
    names = ["Age", TARGET] + [f"{s}_{k}.{t}" for k in INDICATORS for t in ("x", "y") for s in ("Min", "Max", "Mean")]
    mapping = {name: match(raw.columns, name) for name in names}
    frame = pd.DataFrame({name: pd.to_numeric(raw[col], errors="coerce").replace([np.inf, -np.inf], np.nan)
                          for name, col in mapping.items()})
    frame["RecordID"] = raw[match(raw.columns, "RecordID")]
    if frame.RecordID.isna().any() or frame.RecordID.duplicated().any():
        raise ValueError("RecordID must be non-missing and unique for patient-level validation.")
    if sorted(frame[TARGET].dropna().unique()) != [0, 1]:
        raise ValueError("Outcome values do not match the documented 0=survived, 1=died mapping.")
    for key in INDICATORS:
        frame[f"{key}_change"] = frame[f"Mean_{key}.y"] - frame[f"Mean_{key}.x"]
    no_day2 = frame[[f"Mean_{k}.y" for k in INDICATORS]].isna().all(axis=1)
    eligible = frame[TARGET].notna() & ~no_day2
    cohort = frame.loc[eligible].reset_index(drop=True)
    if cohort[TARGET].value_counts().min() < FOLDS:
        raise ValueError("Too few patients in one outcome class for the fixed five-fold protocol.")
    quality = []
    for name, source in mapping.items():
        s = frame[name]
        numeric = pd.to_numeric(raw[source], errors="coerce")
        suspect = (s < 0)
        if name == "Age": suspect = (s <= 0) | (s > 120)
        elif "GCS" in name: suspect = (s < 3) | (s > 15)
        elif "RespRate" in name or "Creatinine" in name: suspect = s <= 0
        quality.append({"Feature": name, "Original_dtype": str(raw[source].dtype), "Nonmissing": int(s.count()),
                        "Missing": int(s.isna().sum()), "Missing_fraction": s.isna().mean(),
                        "Conversion_failures": int((raw[source].notna() & numeric.isna()).sum()),
                        "Nonfinite": int((numeric.notna() & ~np.isfinite(numeric)).sum()),
                        "Unique_values": s.nunique(), "Most_common_value_count": s.value_counts().max(),
                        "Zeros": int(s.eq(0).sum()), "Values_needing_review": int(suspect.sum())})
    selection = pd.DataFrame([
        {"Item": "Original patients", "Count": len(frame)},
        {"Item": "Missing outcome", "Count": int(frame[TARGET].isna().sum())},
        {"Item": "All five Day-2 means missing", "Count": int(no_day2.sum())},
        {"Item": "Excluded from common modelling cohort", "Count": int((~eligible).sum())},
        {"Item": "Common cohort for every model", "Count": len(cohort)},
    ])
    return frame, cohort, pd.DataFrame(quality), selection, mapping


def feature_sets():
    x = [f"Mean_{k}.x" for k in INDICATORS]
    return {"D1": x, "D1_D2": x + [f"Mean_{k}.y" for k in INDICATORS],
            "D1_Change": x + [f"{k}_change" for k in INDICATORS]}


def family(name):
    return "Age" if name == "Age" else next(k for k in INDICATORS if k in name)


def pipeline(algorithm):
    if algorithm == "LR":
        estimator = LogisticRegression(C=1.0, solver="lbfgs", max_iter=3000, tol=1e-7,
                                       class_weight=None, random_state=SEED)
        scaling = StandardScaler()
    else:
        estimator = RandomForestClassifier(n_estimators=200, criterion="gini", max_depth=None,
                    min_samples_split=2, min_samples_leaf=3, max_features="sqrt", bootstrap=True,
                    class_weight=None, random_state=SEED, n_jobs=1)
        scaling = "passthrough"
    return Pipeline([("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
                     ("scaler", scaling), ("classifier", estimator)])


def shuffled_auc_drop(fitted, X, y, columns, baseline, seed):
    rng = np.random.default_rng(seed)
    drops = []
    for _ in range(SHUFFLES):
        shuffled = X.copy()
        order = rng.permutation(len(X))
        shuffled.loc[:, columns] = X.iloc[order][columns].to_numpy()
        probability = fitted.predict_proba(shuffled)[:, 1]
        drops.append(baseline - roc_auc_score(y, probability))
    return float(np.mean(drops))


def evaluate(cohort, audit):
    y = cohort[TARGET].astype(int)
    splits = list(RepeatedStratifiedKFold(n_splits=FOLDS, n_repeats=REPEATS, random_state=SEED).split(cohort, y))
    definitions = []
    for scheme, cols in feature_sets().items():
        for algorithm in ("LR", "RF"):
            definitions.append((f"{algorithm}_{scheme}_Age", algorithm, scheme, True, cols + ["Age"]))
        definitions.append((f"LR_{scheme}_Reference", "LR", scheme, False, cols))
    scores, predictions, groups, individuals, native, inputs = [], [], [], [], [], []
    with threadpool_limits(limits=1), warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        for model, algorithm, scheme, with_age, columns in definitions:
            X = cohort[columns]
            template = pipeline(algorithm)
            inputs.extend({"Model": model, "Algorithm": algorithm, "Scheme": scheme, "With_Age": with_age,
                           "Feature": col, "Indicator": family(col)} for col in columns)
            print(f"Evaluating {model}: {len(splits)} paired validation folds.", flush=True)
            for index, (train, test) in enumerate(splits):
                fitted = clone(template).fit(X.iloc[train], y.iloc[train])
                probability = fitted.predict_proba(X.iloc[test])[:, 1]
                predicted = probability >= 0.5
                yt = y.iloc[test]
                tn, fp, fn, tp = confusion_matrix(yt, predicted, labels=[0, 1]).ravel()
                auc = roc_auc_score(yt, probability)
                scores.append({"Model": model, "Algorithm": algorithm, "Scheme": scheme, "With_Age": with_age,
                    "Repeat": index // FOLDS + 1, "Fold": index % FOLDS + 1, "Features": len(columns),
                    "ROC_AUC": auc, "Recall": recall_score(yt, predicted, zero_division=0),
                    "F1": f1_score(yt, predicted, zero_division=0), "Accuracy": accuracy_score(yt, predicted),
                    "TN": tn, "FP": fp, "FN": fn, "TP": tp})
                predictions.extend((model, index // FOLDS + 1, index % FOLDS + 1, cohort.loc[j, "RecordID"],
                                    int(y.loc[j]), float(p)) for j, p in zip(test, probability))
                if with_age:
                    for number, indicator in enumerate((*INDICATORS, "Age")):
                        related = [c for c in columns if family(c) == indicator]
                        drop = shuffled_auc_drop(fitted, X.iloc[test], yt, related, auc, SEED + index * 100 + number)
                        groups.append({"Model": model, "Algorithm": algorithm, "Scheme": scheme, "CV_index": index,
                                       "Indicator": indicator, "AUC_drop": drop})
                    # Individual-feature inspection uses only the first repeat (five held-out folds).
                    if index < FOLDS:
                        for number, col in enumerate(columns):
                            drop = shuffled_auc_drop(fitted, X.iloc[test], yt, [col], auc, SEED + index * 100 + number)
                            individuals.append({"Model": model, "Feature": col, "AUC_drop": drop})
                    values = fitted.named_steps["classifier"].coef_[0] if algorithm == "LR" else fitted.named_steps["classifier"].feature_importances_
                    native.extend({"Model": model, "Feature": col, "Value": float(v)} for col, v in zip(columns, values))
                if (index + 1) % 10 == 0:
                    print(f"  {index + 1}/{len(splits)} folds complete.", flush=True)
    scores = pd.DataFrame(scores)
    scores.to_csv(audit / "Fold_Metrics.csv", index=False)
    pd.DataFrame(predictions, columns=["Model", "Repeat", "Fold", "RecordID", "Outcome", "Probability"]).to_csv(audit / "Validation_Predictions.csv", index=False)
    pd.DataFrame(groups).to_csv(audit / "Grouped_Permutation_Folds.csv", index=False)
    summary = []
    for model, algorithm, scheme, with_age, cols in definitions:
        ss = scores[scores.Model == model]
        row = {"Model": model, "Algorithm": algorithm, "Scheme": scheme, "With_Age": with_age,
               "Features": len(cols), "Patients": len(cohort), "Evaluations": len(ss)}
        for metric in METRICS:
            row[f"{metric}_Mean"] = ss[metric].mean()
            row[f"{metric}_SD"] = ss[metric].std(ddof=1)
            row[metric] = f"{ss[metric].mean():.4f} +/- {ss[metric].std(ddof=1):.4f}"
        summary.append(row)
    summary = pd.DataFrame(summary)
    primary = summary[summary.With_Age].copy()
    primary["Mean_metric_rank"] = primary[[m + "_Mean" for m in METRICS]].rank(ascending=False).mean(axis=1)
    primary["Mean_metric_SD"] = primary[[m + "_SD" for m in METRICS]].mean(axis=1)
    primary = primary.sort_values(["Mean_metric_rank", "Mean_metric_SD"]).reset_index(drop=True)
    paired = []
    pairs = []
    for scheme in SCHEMES:
        pairs.append((f"LR_{scheme}_Reference", f"LR_{scheme}_Age", "Add Age to LR"))
        pairs.append((f"LR_{scheme}_Age", f"RF_{scheme}_Age", "RF minus LR"))
    for algorithm in ("LR", "RF"):
        for scheme in ("D1_D2", "D1_Change"):
            pairs.append((f"{algorithm}_D1_Age", f"{algorithm}_{scheme}_Age", "Add Day 2 or Change"))
    for before, after, kind in pairs:
        a = scores[scores.Model == before].set_index(["Repeat", "Fold"])
        b = scores[scores.Model == after].set_index(["Repeat", "Fold"])
        for metric in METRICS:
            delta = b[metric] - a[metric]
            paired.append({"Comparison": kind, "Before": before, "After": after, "Metric": metric,
                           "Mean_difference": delta.mean(), "SD_difference": delta.std(ddof=1),
                           "Positive_fold_fraction": delta.gt(0).mean()})
    grouped = pd.DataFrame(groups).groupby(["Model", "Algorithm", "Scheme", "Indicator"], sort=False).AUC_drop.agg(["mean", "std", "count"]).reset_index()
    grouped.columns = ["Model", "Algorithm", "Scheme", "Indicator", "AUC_drop_Mean", "AUC_drop_SD", "Folds"]
    single = pd.DataFrame(individuals).groupby(["Model", "Feature"], sort=False).AUC_drop.agg(["mean", "std", "count"]).reset_index()
    single.columns = ["Model", "Feature", "AUC_drop_Mean", "AUC_drop_SD", "Heldout_folds"]
    intrinsic = pd.DataFrame(native).groupby(["Model", "Feature"], sort=False).Value.agg(["mean", "std"]).reset_index()
    intrinsic.columns = ["Model", "Feature", "Value_Mean", "Value_SD"]
    intrinsic["Absolute_Mean"] = intrinsic.Value_Mean.abs()
    intrinsic = intrinsic.sort_values(["Model", "Absolute_Mean"], ascending=[True, False])
    intrinsic["Interpretation"] = np.where(intrinsic.Model.str.startswith("LR_"), "Standardized conditional LR coefficient", "RF impurity importance; secondary evidence only")
    return primary, summary[~summary.With_Age].copy(), pd.DataFrame(paired), grouped, single, intrinsic, pd.DataFrame(inputs), scores


def descriptive(frame, columns):
    rows = []
    for name in columns:
        s = frame[name]
        rows.append({"Feature": name, "Count": s.count(), "Mean": s.mean(), "Median": s.median(),
                     "SD": s.std(ddof=1), "Q1": s.quantile(.25), "Q3": s.quantile(.75), "Min": s.min(), "Max": s.max()})
    return pd.DataFrame(rows)


def group_statistics(frame, columns):
    rows = []
    for name in columns:
        for code, label in ((0, "Survived"), (1, "Died")):
            s = frame.loc[frame[TARGET].eq(code), name]
            rows.append({"Feature": name, "Outcome": label, "Count": s.count(), "Mean": s.mean(),
                         "Median": s.median(), "Q1": s.quantile(.25), "Q3": s.quantile(.75)})
    return pd.DataFrame(rows)


def handoff(grouped, cohort):
    evidence = grouped[(grouped.Scheme != "D1") & (grouped.Indicator != "Age")].copy()
    evidence["Rank_within_model"] = evidence.groupby("Model").AUC_drop_Mean.rank(ascending=False, method="average")
    ranking = evidence.groupby("Indicator").agg(Mean_rank=("Rank_within_model", "mean"),
        Mean_grouped_AUC_drop=("AUC_drop_Mean", "mean"), Models=("Model", "nunique")).reset_index()
    ranking = ranking.sort_values(["Mean_rank", "Mean_grouped_AUC_drop"], ascending=[True, False]).reset_index(drop=True)
    ranking["Priority"] = np.arange(1, len(ranking) + 1)
    ranking["Recommendation"] = np.where(ranking.Priority <= 3, "Proposed for integration", "Retain as reviewed alternative")
    ranking["Selection_status"] = "Exploratory; validate selection inside the final-model training folds"
    ranking["Caution"] = ranking.Indicator.map({"GCS": "Conditional association, not a causal effect",
        "RespRate": "Many repeated values; origin unknown; do not drop automatically",
        "BUN": "Right-skewed; consider medians and correlated renal markers",
        "Creatinine": "Correlated renal information can dilute permutation importance",
        "Urine": "Recording interval and units are not documented"})
    return ranking, evidence


def save_book(path, sheets, note):
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for name, frame in sheets.items():
            frame.to_excel(writer, sheet_name=name, index=False, startrow=2)
            ws = writer.sheets[name]
            ws.cell(1, 1, note)
            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(1, len(frame.columns)))
            ws.cell(1, 1).font = Font(name="Arial", color="000000", size=10)
            ws.cell(1, 1).alignment = Alignment(wrap_text=True, vertical="center")
            ws.row_dimensions[1].height = 45
            ws.row_dimensions[3].height = 36
            ws.freeze_panes = "B4"
            ws.auto_filter.ref = f"A3:{get_column_letter(len(frame.columns))}{max(3, ws.max_row)}"
            for cell in ws[3]:
                cell.font = Font(name="Arial", bold=True, color="000000")
                cell.fill = PatternFill("solid", fgColor="E9ECEF")
                cell.alignment = Alignment(wrap_text=True, vertical="center")
            for row in ws.iter_rows(min_row=4):
                for cell in row:
                    cell.font = Font(name="Arial", color="000000", size=10)
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
                    if isinstance(cell.value, float): cell.number_format = "0.0000"
            for number, col in enumerate(frame.columns, 1):
                values = frame[col].astype(str).head(40)
                ws.column_dimensions[get_column_letter(number)].width = min(50, max(14, len(str(col)) + 2, values.str.len().max() + 2 if len(values) else 14))


def figures(primary, grouped, single, cohort, root):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "text.color": "black",
                         "axes.labelcolor": "black", "axes.titlecolor": "black"})
    models = [f"{a}_{s}_Age" for s in SCHEMES for a in ("LR", "RF")]
    table = primary.set_index("Model").loc[models]
    colors = ["#536878", "#2B8C84"] * 3
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    for ax, metric in zip(axes.ravel(), METRICS):
        ax.bar(np.arange(6), table[metric + "_Mean"], yerr=table[metric + "_SD"], capsize=4, color=colors)
        ax.set_xticks(np.arange(6), [f"{a}\n{s}" for s in ("D1", "D1+D2", "D1+Change") for a in ("LR", "RF")], fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_title(metric.replace("_", "-"))
        ax.grid(axis="y", alpha=.25)
        for i, value in enumerate(table[metric + "_Mean"]): ax.text(i, value + table.iloc[i][metric + "_SD"] + .022, f"{value:.3f}", ha="center", fontsize=9)
    fig.suptitle("Age included in all six primary models | Same patients and CV splits", fontsize=15)
    fig.text(.5, .025, "Bars: means of 50 validation scores. Error bars: sample SD, not confidence intervals.", ha="center", fontsize=10)
    fig.tight_layout(rect=(0, .06, 1, .95)); fig.savefig(root / "Model_Comparison.png", dpi=300); plt.close(fig)
    for table_name, source, key, filename, subtitle in (
        ("Grouped", grouped, "Indicator", "Grouped_Importance.png", "Jointly shuffle all representations of each indicator | 50 held-out folds"),
        ("Individual", single, "Feature", "Feature_Importance.png", "Individual feature shuffling | first repeat only: 5 held-out folds")):
        fig, axes = plt.subplots(3, 2, figsize=(13, 13))
        ordered_models = [f"{a}_{s}_Age" for s in SCHEMES for a in ("LR", "RF")]
        for ax, model in zip(axes.ravel(), ordered_models):
            rows = source[source.Model.eq(model)].sort_values("AUC_drop_Mean")
            ax.barh(rows[key], rows.AUC_drop_Mean, xerr=rows.AUC_drop_SD, capsize=3,
                    color="#536878" if model.startswith("LR") else "#2B8C84")
            ax.axvline(0, color="black", linewidth=.7)
            ax.set_title(model, fontsize=12)
            ax.set_xlabel("Held-out ROC-AUC drop after shuffling", fontsize=10)
            ax.tick_params(axis="y", labelsize=9)
            ax.grid(axis="x", alpha=.2)
        fig.suptitle(f"{table_name} permutation importance (Age retained)", fontsize=16)
        fig.text(.5, .028, subtitle, ha="center", fontsize=10)
        fig.text(.5, .012, "3 shuffles per group/feature per fold. Error bars: SD of fold-average drops. Not causal importance.", ha="center", fontsize=9)
        fig.tight_layout(rect=(0, .065, 1, .95)); fig.savefig(root / filename, dpi=300); plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    for code, label, color in ((0, "Survived", "#536878"), (1, "Died", "#2B8C84")):
        axes[0].hist(cohort.loc[cohort[TARGET].eq(code), "Age"].dropna(), bins=np.arange(15, 96, 5), density=True, alpha=.5, label=label, color=color)
    axes[0].set_xlabel("Age (years)"); axes[0].set_ylabel("Density"); axes[0].legend()
    axes[1].boxplot([cohort.loc[cohort[TARGET].eq(code), "Age"].dropna() for code in (0, 1)], tick_labels=["Survived", "Died"], showfliers=True)
    axes[1].set_ylabel("Age (years)")
    fig.suptitle("Age by outcome: original values retained", fontsize=14)
    fig.tight_layout(); fig.savefig(root / "Age_Distribution.png", dpi=300); plt.close(fig)


WORD_SCRIPT = r'''
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType,
        ShadingType, BorderStyle, Header, Footer, PageNumber, AlignmentType, ImageRun } = require("docx");
const data = JSON.parse(fs.readFileSync(0, "utf8"));
const para = text => new Paragraph({children:[new TextRun({text,color:"000000"})],spacing:{after:100}});
const heading = text => new Paragraph({style:"Heading1",children:[new TextRun({text,color:"000000",bold:true})]});
const widths = [1900,1775,1775,1775,1775];
const border = {style:BorderStyle.SINGLE,size:4,color:"AAAAAA"};
const cell = (text,index,bold) => new TableCell({width:{size:widths[index],type:WidthType.DXA},
  margins:{top:80,bottom:80,left:80,right:80},borders:{top:border,bottom:border,left:border,right:border},
  shading:{fill:bold?"E9ECEF":"FFFFFF",type:ShadingType.CLEAR},
  children:[new Paragraph({children:[new TextRun({text:String(text),size:17,color:"000000",bold})]})]});
const children = [new Paragraph({style:"Title",children:[new TextRun({text:"ICU Mortality: Age, LR and RF",color:"000000",bold:true})]}),
  para(data.overview),heading("1. Model comparison"),para(data.method),
  new Table({width:{size:9000,type:WidthType.DXA},columnWidths:widths,
    rows:[new TableRow({tableHeader:true,cantSplit:true,children:["Model","ROC-AUC","Recall","F1","Accuracy"].map((x,i)=>cell(x,i,true))}),
      ...data.table.map(row=>new TableRow({cantSplit:true,children:row.map((x,i)=>cell(x,i,false))}))]}),
  para("All six models include Age. D1: Day 1; D1+D2: both days; D1+Ch: Day 1 and individual change. Values are mean +/- sample SD."),
  heading("2. Main findings"),...data.findings.map(para),
  heading("3. Variables for the final-model owner"),...data.handoff.map(para),
  heading("4. Data quality and limits"),...data.limits.map(para),
  heading("5. Files and reproducibility"),para(data.files),para(data.parameters),
  heading("Method references"),...data.references.map(t=>new Paragraph({children:[new TextRun({text:t,size:17,color:"000000"})],spacing:{after:80}}))];
const doc = new Document({creator:"",lastModifiedBy:"",title:"ICU Mortality Analysis Summary",
  styles:{default:{document:{run:{font:"Arial",size:21,color:"000000"},paragraph:{spacing:{line:264,after:100}}}},
    paragraphStyles:[{id:"Title",name:"Title",basedOn:"Normal",next:"Normal",run:{font:"Arial",size:36,bold:true,color:"000000"},paragraph:{spacing:{after:200}}},
      {id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,run:{font:"Arial",size:26,bold:true,color:"000000"},paragraph:{outlineLevel:0,keepNext:true,spacing:{before:180,after:100}}}]},
  sections:[{properties:{page:{size:{width:11906,height:16838},margin:{top:1000,bottom:1000,left:1453,right:1453}}},
    headers:{default:new Header({children:[new Paragraph({alignment:AlignmentType.RIGHT,children:[new TextRun({text:"ICU Mortality Project | Age update",size:16,color:"000000"})]})]})},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:"Page ",color:"000000",size:16}),new TextRun({children:[PageNumber.CURRENT],color:"000000",size:16})]})]})},children}]});
Packer.toBuffer(doc).then(buffer=>fs.writeFileSync(data.output,buffer)).catch(e=>{console.error(e);process.exit(1)});
'''


def report(primary, reference, paired, ranking, grouped, cohort, digest, root, plot_errors):
    best = primary.iloc[0]
    best_auc = primary.loc[primary.ROC_AUC_Mean.idxmax()]
    best_recall = primary.loc[primary.Recall_Mean.idxmax()]
    selected = ranking.head(3).Indicator.tolist()
    age_stats = cohort.groupby(TARGET).Age.agg(["mean", "median"])
    common_rr = cohort[[f"{s}_RespRate.y" for s in ("Min", "Max", "Mean")]].value_counts().iloc[0]
    findings = [f"The descriptive overall candidate is {best.Model}: ROC-AUC {best.ROC_AUC}, Recall {best.Recall}, F1 {best.F1}, Accuracy {best.Accuracy}. The rule is the equal-weight mean rank of the four metric means, with mean SD only as a tie-breaker. This is not a clinical utility score or evidence of significant superiority.",
        f"The highest mean ROC-AUC is from {best_auc.Model} ({best_auc.ROC_AUC}); the highest death Recall is from {best_recall.Model} ({best_recall.Recall}). Recall at 0.5 must be considered alongside AUC and F1, not only Accuracy."]
    for scheme in SCHEMES:
        delta = paired[(paired.Comparison == "Add Age to LR") & (paired.After == f"LR_{scheme}_Age")]
        text = "; ".join(f"{r.Metric} {r.Mean_difference:+.4f}" for r in delta.itertuples())
        findings.append(f"Adding Age to LR ({SCHEMES[scheme]}), compared with the same five-indicator reference: {text}. These are paired descriptive changes, not statistical significance tests.")
    for scheme in SCHEMES:
        delta = paired[(paired.Comparison == "RF minus LR") & (paired.After == f"RF_{scheme}_Age")]
        findings.append(f"RF minus LR ({SCHEMES[scheme]}, both with Age): " + "; ".join(f"{r.Metric} {r.Mean_difference:+.4f}" for r in delta.itertuples()) + ".")
    age_deltas = paired[paired.Comparison == "Add Age to LR"]
    age_auc = age_deltas[age_deltas.Metric == "ROC_AUC"]
    compact_age = (f"Adding Age increased {int(age_deltas.Mean_difference.gt(0).sum())} of {len(age_deltas)} LR metric means. "
                   + "AUC changes: " + "; ".join(f"{SCHEMES[r.After.removeprefix('LR_').removesuffix('_Age')]} {r.Mean_difference:+.4f}" for r in age_auc.itertuples())
                   + ". Age is retained as requested. These paired descriptive changes are not significance tests.")
    rf_deltas = paired[paired.Comparison == "RF minus LR"]
    compact_rf = ("RF had higher means than LR on " + "; ".join(
        f"{int(rf_deltas.loc[rf_deltas.After.eq('RF_' + scheme + '_Age'), 'Mean_difference'].gt(0).sum())}/{len(METRICS)} metrics for {label}"
        for scheme, label in SCHEMES.items())
        + ". The RF settings were fixed before evaluation; this is not a tuned optimum.")
    integration = [f"Proposed indicator shortlist: {', '.join(selected)}. Age is mandatory and does not count towards the two-to-three assigned-indicator shortlist. The five indicator families remain in all reported primary models; no reduced-model performance is claimed.",
        "Ranking uses the mean within-model rank of grouped held-out permutation AUC drops across the four Day-2/Change models (LR and RF). Each indicator's paired representations are shuffled jointly, preserving their within-indicator relationship. LR coefficients, RF impurity importance, individual permutation results and group medians provide additional context."]
    for r in ranking.head(3).itertuples():
        medians = cohort.groupby(TARGET)[f"Mean_{r.Indicator}.y"].median()
        integration.append(f"{r.Priority}. {r.Indicator}: mean rank {r.Mean_rank:.2f}, average grouped AUC drop {r.Mean_grouped_AUC_drop:.4f}. "
                           f"Day-2 medians: survived {medians.loc[0]:.2f}, died {medians.loc[1]:.2f} (original units). {r.Caution}.")
    integration.append("This shortlist is exploratory because the same repeated CV supports comparison and inspection. The final-model owner must perform any selection and tuning inside their training folds and independently validate the final combined model. Do not treat the selected candidate's CV score as an unbiased estimate after model selection.")
    limits = [f"Common cohort: {len(cohort):,} patients; survived {int(cohort[TARGET].eq(0).sum()):,}; died {int(cohort[TARGET].eq(1).sum()):,} ({cohort[TARGET].mean():.2%}). Outcome semantics 0=survived and 1=died follow the existing project notebook; actual numeric codes were checked. Original data and patient rows were retained.",
        f"Age: mean {cohort.Age.mean():.2f}, median {cohort.Age.median():.2f}, range {cohort.Age.min():.0f}-{cohort.Age.max():.0f} years; missing {int(cohort.Age.isna().sum())}. Survived mean {age_stats.loc[0,'mean']:.2f} versus died mean {age_stats.loc[1,'mean']:.2f}; group medians are {age_stats.loc[0,'median']:.0f} and {age_stats.loc[1,'median']:.0f}. There are {int(cohort.Age.eq(90).sum())} values equal to 90; any top-coding policy is unknown. No monotonic mortality claim is inferred from Age alone.",
        f"RespRate: the most frequent Day-2 Min/Max/Mean tuple occurs in {int(common_rr)} patients ({common_rr/len(cohort):.2%}). Its origin is unknown. {int(cohort['Min_RespRate.y'].eq(0).sum())} Day-2 minimum respiratory rates equal zero and need context; they were not deleted. No outlier removal, winsorization or resampling was used.",
        "BUN, Creatinine and Urine are skewed; medians and quartiles are included in the handoff workbook. The file does not document renal/urine units, urine recording intervals, original missingness or upstream imputation. This pipeline prevents new fold-preprocessing leakage, but cannot certify the upstream preprocessing.",
        "Day-2 and Change models need information through approximately 48 hours; they are not admission-time predictions. Raw timestamps are unavailable, so actual availability cannot be independently checked. D1+D2 and D1+Change contain equivalent paired information but differ as feature representations; LR penalties and axis-aligned RF splits can yield different results.",
        "SD is the sample SD of correlated validation scores, not a confidence interval. Permutation importance is model-dependent and may be diluted by correlated indicators; RF impurity importance can be biased. No causal claims, p-values, external validation, threshold tuning or clinical deployment claim are made."]
    data = {"overview": "Update of the five assigned ICU indicators (GCS, RespRate, BUN, Creatinine, Urine): add Age, compare Logistic Regression (LR) and Random Forest (RF), and prepare an integration handoff. No other Patient Profile variables are included.",
        "method": "All models share one patient cohort and the same 5-fold x 10-repeat stratified splits (seed 42). Training-fold median imputation is used in both pipelines; LR also uses training-fold StandardScaler. Death is the positive class; classification threshold is fixed at 0.5. There is no tuning or oversampling.",
        "table": [[r.Model.replace("_Age", "").replace("D1_Change", "D1+Ch").replace("D1_D2", "D1+D2")] + [r[m] for m in METRICS] for _, r in primary.iterrows()],
        "findings": [f"The descriptive overall candidate is {best.Model}. Selection uses the equal-weight mean rank of all four metric means, with mean SD as a tie-breaker; this is not a clinical utility score or evidence of significant superiority.",
                     findings[1], compact_age, compact_rf],
        "handoff": integration, "limits": limits,
        "files": "results/: Model_Comparison.xlsx, Feature_Importance.xlsx, Variable_Handoff.xlsx, Data_Quality_and_Age.xlsx, Analysis_Data.csv and Integration_Data.csv. figures/: model comparison, grouped importance, individual importance and Age distribution. run_analysis.py rebuilds the results; run_analysis.cmd is the Windows launcher. Raw input: data/ICU_Preprocessed_Data.csv.",
        "parameters": "LR: L2, C=1, lbfgs, max_iter=3000, tol=1e-7. RF: 200 trees, Gini, min_samples_leaf=3, min_samples_split=2, max_features=sqrt, no depth cap, bootstrap=True, class_weight=None, seed=42. Settings were fixed before evaluation; no hyperparameter search. Raw input SHA-256: " + digest,
        "references": ["Source: client weekly task checklist and chat confirmation (Age only; English deliverables). Existing project notebook supplies outcome semantics.",
            "scikit-learn official documentation, permutation importance: https://scikit-learn.org/stable/modules/permutation_importance.html",
            "scikit-learn official documentation, RandomForestClassifier: https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html"],
        "output": str(root / "ICU_Analysis_Summary.docx")}
    if plot_errors: data["limits"].append("Figure warnings: " + "; ".join(plot_errors))
    markdown = ["# ICU Mortality: Age, Logistic Regression and Random Forest", "", data["overview"], "", "## Model comparison", "", data["method"], "",
                "| Model | ROC-AUC | Recall | F1 | Accuracy |", "|---|---|---|---|---|"]
    markdown.extend("| " + " | ".join(row) + " |" for row in data["table"])
    for title, paragraphs in (("Main findings", findings), ("Integration handoff", integration), ("Data quality and limits", limits), ("Files and reproducibility", [data["files"], data["parameters"]]), ("Method references", data["references"])):
        markdown.extend(["", "## " + title, ""])
        for paragraph in paragraphs: markdown.extend([paragraph, ""])
    (root / "Analysis_Summary.md").write_text("\n".join(markdown), encoding="utf-8")
    node = shutil.which("node")
    if not node: raise RuntimeError("Node.js is needed to reproduce the Word report; the Markdown report was saved.")
    env = os.environ.copy()
    npm = shutil.which("npm.cmd" if os.name == "nt" else "npm")
    if npm:
        result = subprocess.run([npm, "root", "-g"], shell=os.name == "nt", capture_output=True, text=True, check=True)
        env["NODE_PATH"] = os.pathsep.join(filter(None, [result.stdout.strip(), env.get("NODE_PATH")]))
    subprocess.run([node, "-e", WORD_SCRIPT], input=json.dumps(data), text=True, encoding="utf-8", env=env, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", help="Optional CSV/XLSX input; default is automatic discovery")
    parser.add_argument("--output", help="Optional output folder")
    args = parser.parse_args()
    home = Path(__file__).resolve().parent
    root = Path(args.output).resolve() if args.output else home
    audit = root.parent / "ICU_Age_LR_RF_Verification_20261008"
    for path in (root / "results", root / "figures", audit): path.mkdir(parents=True, exist_ok=True)
    source = locate_data(home, args.data)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    raw = read_file(source)
    frame, cohort, quality, selection, mapping = prepare(raw)
    primary, reference, paired, grouped, single, native, inputs, scores = evaluate(cohort, audit)
    ranking, evidence = handoff(grouped, cohort)
    settings = pd.DataFrame({"Setting": ["Seed", "CV", "Threshold", "Positive_class", "Imputation", "LR_scaling", "RF_scaling", "Tuning", "Resampling", "Grouped_importance", "Individual_importance", "Outcome_semantics", "Raw_SHA256"],
        "Value": ["42", "5 folds x 10 repeats; identical indices for all models", "0.5", "1 (died)", "Training-fold median", "Training-fold StandardScaler", "None (trees do not require scaling)", "None", "None", "50 held-out folds, 3 joint shuffles per group per fold", "First repeat: 5 held-out folds, 3 shuffles per feature", "0=survived, 1=died; documented in existing project notebook", digest]})
    params = pd.DataFrame([{"Algorithm": a, "Parameter": key, "Value": str(value)} for a in ("LR", "RF") for key, value in pipeline(a).named_steps["classifier"].get_params().items()])
    columns = ["Model", "Algorithm", "Scheme", "Features", "Patients", "Evaluations", *METRICS]
    note = "Actual-data analysis. Death=1; threshold=0.5. Same patients and splits. Sample SD, not confidence intervals."
    save_book(root / "results" / "Model_Comparison.xlsx", {"Primary_Mean_SD": primary[columns], "Primary_Numeric": primary.drop(columns=list(METRICS)), "LR_No_Age_Reference": reference, "Paired_Differences": paired, "Model_Inputs": inputs, "Settings": settings, "Estimator_Parameters": params}, note)
    save_book(root / "results" / "Feature_Importance.xlsx", {"Grouped_Permutation": grouped, "Individual_Permutation": single, "LR_Coefficients_RF_MDI": native}, "Grouped: 50 validation folds; individual: first 5 folds. Three shuffles each. Conditional contribution, not causality. SD is across fold-average drops.")
    integration_columns = ["RecordID", "Age"] + [f"Mean_{k}.x" for k in ranking.head(3).Indicator] + [f"Mean_{k}.y" for k in ranking.head(3).Indicator] + [f"{k}_change" for k in ranking.head(3).Indicator] + [TARGET]
    handoff_inputs = inputs[inputs.With_Age].copy()
    chosen = set(ranking.head(3).Indicator) | {"Age"}
    handoff_inputs = handoff_inputs[handoff_inputs.Indicator.isin(chosen)]
    handoff_inputs["Status"] = "Proposed reduced feature lists only; no reduced-model CV score claimed"
    groups = group_statistics(cohort, ["Age"] + [f"Mean_{k}.{t}" for k in INDICATORS for t in ("x", "y")] + [f"{k}_change" for k in INDICATORS])
    save_book(root / "results" / "Variable_Handoff.xlsx", {"Indicator_Shortlist": ranking, "Ranking_Evidence": evidence, "Proposed_Model_Inputs": handoff_inputs, "Outcome_Group_Statistics": groups}, "Age is mandatory. Top 3 indicator families are exploratory proposals, not validated selection. Final-model owner must repeat selection inside training folds. Never use x+y+change together.")
    save_book(root / "results" / "Data_Quality_and_Age.xlsx", {"Feature_Quality": quality, "Common_Cohort": selection, "Age_Statistics": descriptive(cohort, ["Age"]), "Age_by_Outcome": group_statistics(cohort, ["Age"]), "Column_Mapping": pd.DataFrame(mapping.items(), columns=["Expected", "Original"])}, "Raw records retained. No outlier deletion. Range flags need context. Missingness refers to the supplied preprocessed file, not the original raw records.")
    frame.to_csv(root / "results" / "Analysis_Data.csv", index=False)
    cohort[integration_columns].to_csv(root / "results" / "Integration_Data.csv", index=False)
    plot_errors = []
    try: figures(primary, grouped, single, cohort, root / "figures")
    except Exception as error: plot_errors.append(str(error))
    report(primary, reference, paired, ranking, grouped, cohort, digest, root, plot_errors)
    if hashlib.sha256(source.read_bytes()).hexdigest() != digest: raise AssertionError("The original dataset changed.")
    print(primary[columns].to_string(index=False), flush=True)
    print("Proposed indicator shortlist: " + ", ".join(ranking.head(3).Indicator), flush=True)
    print("Delivery folder: " + str(root), flush=True)
    if plot_errors: print("Figure warnings: " + "; ".join(plot_errors), flush=True)


if __name__ == "__main__":
    main()
