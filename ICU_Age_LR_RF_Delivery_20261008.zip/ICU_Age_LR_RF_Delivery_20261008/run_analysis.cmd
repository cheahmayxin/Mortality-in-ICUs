@echo off
cd /d "%~dp0"
python run_analysis.py
if errorlevel 1 (
  echo Analysis failed. Review the error above.
) else (
  echo Analysis complete. Results, figures and reports are ready.
)
pause
