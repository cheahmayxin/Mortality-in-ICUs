# ICU Mortality: Age, Logistic Regression and Random Forest

Update of the five assigned ICU indicators (GCS, RespRate, BUN, Creatinine, Urine): add Age, compare Logistic Regression (LR) and Random Forest (RF), and prepare an integration handoff. No other Patient Profile variables are included.

## Model comparison

All models share one patient cohort and the same 5-fold x 10-repeat stratified splits (seed 42). Training-fold median imputation is used in both pipelines; LR also uses training-fold StandardScaler. Death is the positive class; classification threshold is fixed at 0.5. There is no tuning or oversampling.

| Model | ROC-AUC | Recall | F1 | Accuracy |
|---|---|---|---|---|
| LR_D1+D2 | 0.7423 +/- 0.0246 | 0.4786 +/- 0.0376 | 0.5419 +/- 0.0323 | 0.6963 +/- 0.0211 |
| LR_D1+Ch | 0.7424 +/- 0.0246 | 0.4779 +/- 0.0382 | 0.5415 +/- 0.0324 | 0.6963 +/- 0.0208 |
| RF_D1+D2 | 0.7359 +/- 0.0236 | 0.4722 +/- 0.0406 | 0.5402 +/- 0.0353 | 0.6984 +/- 0.0225 |
| RF_D1+Ch | 0.7306 +/- 0.0227 | 0.4488 +/- 0.0413 | 0.5161 +/- 0.0368 | 0.6845 +/- 0.0219 |
| RF_D1 | 0.6755 +/- 0.0302 | 0.3932 +/- 0.0417 | 0.4669 +/- 0.0390 | 0.6634 +/- 0.0240 |
| LR_D1 | 0.6608 +/- 0.0296 | 0.3137 +/- 0.0374 | 0.4105 +/- 0.0416 | 0.6619 +/- 0.0241 |

## Main findings

The descriptive overall candidate is LR_D1_D2_Age: ROC-AUC 0.7423 +/- 0.0246, Recall 0.4786 +/- 0.0376, F1 0.5419 +/- 0.0323, Accuracy 0.6963 +/- 0.0211. The rule is the equal-weight mean rank of the four metric means, with mean SD only as a tie-breaker. This is not a clinical utility score or evidence of significant superiority.

The highest mean ROC-AUC is from LR_D1_Change_Age (0.7424 +/- 0.0246); the highest death Recall is from LR_D1_D2_Age (0.4786 +/- 0.0376). Recall at 0.5 must be considered alongside AUC and F1, not only Accuracy.

Adding Age to LR (Day 1), compared with the same five-indicator reference: ROC_AUC +0.0009; Recall -0.0060; F1 -0.0053; Accuracy -0.0010. These are paired descriptive changes, not statistical significance tests.

Adding Age to LR (Day 1 + Day 2), compared with the same five-indicator reference: ROC_AUC -0.0006; Recall -0.0038; F1 -0.0042; Accuracy -0.0026. These are paired descriptive changes, not statistical significance tests.

Adding Age to LR (Day 1 + Change), compared with the same five-indicator reference: ROC_AUC -0.0007; Recall -0.0043; F1 -0.0044; Accuracy -0.0024. These are paired descriptive changes, not statistical significance tests.

RF minus LR (Day 1, both with Age): ROC_AUC +0.0146; Recall +0.0794; F1 +0.0565; Accuracy +0.0014.

RF minus LR (Day 1 + Day 2, both with Age): ROC_AUC -0.0065; Recall -0.0063; F1 -0.0017; Accuracy +0.0021.

RF minus LR (Day 1 + Change, both with Age): ROC_AUC -0.0118; Recall -0.0291; F1 -0.0254; Accuracy -0.0119.


## Integration handoff

Proposed indicator shortlist: GCS, BUN, Urine. Age is mandatory and does not count towards the two-to-three assigned-indicator shortlist. The five indicator families remain in all reported primary models; no reduced-model performance is claimed.

Ranking uses the mean within-model rank of grouped held-out permutation AUC drops across the four Day-2/Change models (LR and RF). Each indicator's paired representations are shuffled jointly, preserving their within-indicator relationship. LR coefficients, RF impurity importance, individual permutation results and group medians provide additional context.

1. GCS: mean rank 1.00, average grouped AUC drop 0.1802. Day-2 medians: survived 14.05, died 9.25 (original units). Conditional association, not a causal effect.

2. BUN: mean rank 2.75, average grouped AUC drop 0.0284. Day-2 medians: survived 23.00, died 30.17 (original units). Right-skewed; consider medians and correlated renal markers.

3. Urine: mean rank 3.50, average grouped AUC drop 0.0168. Day-2 medians: survived 92.61, died 66.73 (original units). Recording interval and units are not documented.

This shortlist is exploratory because the same repeated CV supports comparison and inspection. The final-model owner must perform any selection and tuning inside their training folds and independently validate the final combined model. Do not treat the selected candidate's CV score as an unbiased estimate after model selection.


## Data quality and limits

Common cohort: 1,474 patients; survived 920; died 554 (37.58%). Outcome semantics 0=survived and 1=died follow the existing project notebook; actual numeric codes were checked. Original data and patient rows were retained.

Age: mean 70.85, median 74.00, range 19-90 years; missing 0. Survived mean 71.38 versus died mean 69.97; group medians are 74 and 74. There are 99 values equal to 90; any top-coding policy is unknown. No monotonic mortality claim is inferred from Age alone.

RespRate: the most frequent Day-2 Min/Max/Mean tuple occurs in 1091 patients (74.02%). Its origin is unknown. 5 Day-2 minimum respiratory rates equal zero and need context; they were not deleted. No outlier removal, winsorization or resampling was used.

BUN, Creatinine and Urine are skewed; medians and quartiles are included in the handoff workbook. The file does not document renal/urine units, urine recording intervals, original missingness or upstream imputation. This pipeline prevents new fold-preprocessing leakage, but cannot certify the upstream preprocessing.

Day-2 and Change models need information through approximately 48 hours; they are not admission-time predictions. Raw timestamps are unavailable, so actual availability cannot be independently checked. D1+D2 and D1+Change contain equivalent paired information but differ as feature representations; LR penalties and axis-aligned RF splits can yield different results.

SD is the sample SD of correlated validation scores, not a confidence interval. Permutation importance is model-dependent and may be diluted by correlated indicators; RF impurity importance can be biased. No causal claims, p-values, external validation, threshold tuning or clinical deployment claim are made.


## Files and reproducibility

results/: Model_Comparison.xlsx, Feature_Importance.xlsx, Variable_Handoff.xlsx, Data_Quality_and_Age.xlsx, Analysis_Data.csv and Integration_Data.csv. figures/: model comparison, grouped importance, individual importance and Age distribution. run_analysis.py rebuilds the results; run_analysis.cmd is the Windows launcher. Raw input: data/ICU_Preprocessed_Data.csv.

LR: L2, C=1, lbfgs, max_iter=3000, tol=1e-7. RF: 200 trees, Gini, min_samples_leaf=3, min_samples_split=2, max_features=sqrt, no depth cap, bootstrap=True, class_weight=None, seed=42. Settings were fixed before evaluation; no hyperparameter search. Raw input SHA-256: 1ee4406edde45468e5f871d0ec6c5a6abb0b81a9530f1fb74379bfaa81e0f223


## Method references

Source: client weekly task checklist and chat confirmation (Age only; English deliverables). Existing project notebook supplies outcome semantics.

scikit-learn official documentation, permutation importance: https://scikit-learn.org/stable/modules/permutation_importance.html

scikit-learn official documentation, RandomForestClassifier: https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html
